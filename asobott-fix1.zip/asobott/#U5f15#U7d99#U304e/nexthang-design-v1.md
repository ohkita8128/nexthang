# NextHang 設計書 v1.0

> 最終更新: 2026年1月31日

---

## 📌 プロジェクト概要

| 項目 | 内容 |
|------|------|
| **名称** | NextHang（暫定） |
| **目的** | 予定が存在しないまま時間が過ぎる問題を解決 |
| **ターゲット** | 仲良しだけど動かない友達グループ |
| **形態** | LINE Bot + 管理画面（LIFF） |

### 解決する課題

```
❌ 従来の問題
├── 日程調整が面倒
├── 幹事がいない
├── 誘うのが心理的に重い
└── 予定が存在しないまま時間が過ぎる ← 真の課題

✅ NextHang の解決策
├── Bot が自動で誘う（誰も言い出さなくていい）
├── 日付なしで「行きたい」を溜められる
├── 人数集まらなくても失敗にならない
└── 全部 LINE 内で完結
```

---

## 🏗 技術スタック

| カテゴリ | 技術 | 備考 |
|---------|------|------|
| フレームワーク | Next.js 14 (App Router) | |
| 言語 | TypeScript | |
| スタイル | Tailwind CSS | |
| DB | Supabase (PostgreSQL) | |
| ホスティング | Vercel | |
| 定期実行 | Supabase Edge Functions | |
| Bot | LINE Messaging API | |
| 管理画面 | LIFF | LINE Front-end Framework |

### コスト見積もり

| 規模 | 月額 |
|------|------|
| 友達（〜10グループ） | 0円 |
| 中規模（〜100グループ） | 0〜1,000円 |
| 大規模（1000グループ〜） | 3,000〜10,000円 |

---

## 🔧 システムアーキテクチャ

```
┌─────────────────────────────────────────────────────────────────┐
│                         ユーザー                                 │
└─────────────────────────────────────────────────────────────────┘
                    │                           │
                    ▼                           ▼
┌─────────────────────────────┐   ┌─────────────────────────────┐
│      LINE トーク画面         │   │    LIFF（管理画面）          │
│  ・Bot からの通知受信        │   │  ・カレンダー表示            │
│  ・リッチメニュー            │   │  ・日程投票                  │
│  ・簡易返信                  │   │  ・行きたいリスト            │
└──────────────┬──────────────┘   └──────────────┬──────────────┘
               │                                  │
               ▼                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                    LINE Messaging API                           │
│                  （Webhook / Push Message）                      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                 Next.js on Vercel                               │
│  ┌─────────────────────┐  ┌─────────────────────────────────┐  │
│  │  /api/webhook       │  │  /liff/*                        │  │
│  │  LINE イベント受信   │  │  管理画面ページ                  │  │
│  └─────────────────────┘  └─────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Supabase                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │  PostgreSQL  │  │  Auth        │  │  Edge Functions      │  │
│  │  データ保存   │  │  (使わない)  │  │  定期実行            │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📋 機能一覧

### Phase 1：MVP（最小限で価値が出る）

| # | 機能 | 説明 |
|---|------|------|
| 1 | 定期お誘い送信 | Bot が自動で「そろそろ遊びませんか？」とグループに送信 |
| 2 | 頻度設定 | グループごとに毎週/2週間/月1/オフを選択可能 |
| 3 | 日程投票 | カレンダーUIで候補日に ○△✕ をつける |
| 4 | リマインド | 1週間前・前日・当日に Bot が自動通知 |
| 5 | リッチメニュー | トーク画面下部に常設メニュー、タップで管理画面へ |
| 6 | 管理画面（LIFF） | LINE内で開くWebアプリ、ログイン不要 |

### Phase 2：差別化（独自の価値）

| # | 機能 | 説明 |
|---|------|------|
| 7 | 行きたい予定（日付なし） | 「ユニバ行きたい」など日付未定で登録できる |
| 8 | 興味投票 | 行きたい予定に「気になる」を押せる、閾値超えたら日程投票へ |
| 9 | 匿名/顕名切り替え | 予定追加時に名前を出すか選べる |
| 10 | 人数不足→保留 | 集まらなかったら失敗扱いせず翌月に自動復活 |
| 11 | 近い予定のまとめ投票 | 7日以内の予定は1画面でまとめて投票 |
| 12 | 投票結果の比較表示 | どの日程が一番人気か一目でわかる |

### Phase 3：発展（将来機能）

| # | 機能 | 説明 |
|---|------|------|
| 13 | おすすめ提案 | 過去の人気予定・季節イベントをBot が提案 |
| 14 | Google Calendar連携 | 個人の予定を見て空き日程を自動判定 |
| 15 | 年間レポート | 「今年は8回集まりました」などの振り返り |
| 16 | 予算感共有 | 「今回は3000円くらいで」を事前設定 |
| 17 | 思い出連携 | 終わった予定に写真を紐付け |
| 18 | 記念日リマインド | 「グループ結成3年です」など |

---

## 🔄 状態遷移

### 予定（Event）のステータス

```
                    ┌──────────────┐
                    │   voting     │ ← 日程投票中
                    └──────┬───────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │confirmed │    │ pending  │    │cancelled │
    │（確定）   │    │（保留）   │    │（中止）   │
    └────┬─────┘    └────┬─────┘    └──────────┘
         │               │
         │               ▼
         │         次月に復活
         │         （voting へ）
         ▼
    ┌──────────┐
    │completed │ ← 終了後
    └──────────┘
```

### 行きたい（Wish）のステータス

```
    ┌──────────┐
    │   open   │ ← 興味集め中
    └────┬─────┘
         │ 閾値超え
         ▼
    ┌──────────┐
    │  voting  │ ← 日程投票中（Event作成）
    └────┬─────┘
         │
         ▼
    ┌──────────┐
    │converted │ ← 予定に変換済み
    └──────────┘

    ※ archived = 古くなって非表示
```

---

## 🗄 データベース設計

### ER図

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   users     │     │   groups    │     │  group_     │
│─────────────│     │─────────────│     │  members    │
│ id (PK)     │◄────│ created_by  │     │─────────────│
│ line_user_id│     │ id (PK)     │◄────│ group_id    │
│ display_name│     │ line_group_ │     │ user_id     │────►┌─────────────┐
│ picture_url │     │   id        │     │ role        │     │   users     │
│ created_at  │     │ name        │     │ joined_at   │     └─────────────┘
└─────────────┘     │ settings    │     └─────────────┘
                    │ created_at  │
                    └─────────────┘
                          │
          ┌───────────────┼───────────────┐
          ▼               ▼               ▼
┌─────────────┐   ┌─────────────┐   ┌─────────────┐
│   events    │   │   wishes    │   │  reminders  │
│─────────────│   │─────────────│   │─────────────│
│ id (PK)     │   │ id (PK)     │   │ id (PK)     │
│ group_id    │   │ group_id    │   │ group_id    │
│ title       │   │ title       │   │ type        │
│ date        │   │ created_by  │   │ scheduled_at│
│ status      │   │ is_anonymous│   │ sent_at     │
│ created_by  │   │ status      │   │ event_id    │
│ created_at  │   │ created_at  │   └─────────────┘
└─────────────┘   └─────────────┘
      │                 │
      ▼                 ▼
┌─────────────┐   ┌─────────────┐
│   votes     │   │  interests  │
│─────────────│   │─────────────│
│ id (PK)     │   │ id (PK)     │
│ event_id    │   │ wish_id     │
│ user_id     │   │ user_id     │
│ date        │   │ created_at  │
│ response    │   └─────────────┘
│ created_at  │
└─────────────┘
```

### テーブル定義

#### users（ユーザー）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| line_user_id | text | LINE のユーザーID（一意） |
| display_name | text | LINE の表示名 |
| picture_url | text | LINE のアイコンURL |
| created_at | timestamp | 登録日時 |
| updated_at | timestamp | 更新日時 |

```sql
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  line_user_id text UNIQUE NOT NULL,
  display_name text,
  picture_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_users_line_user_id ON users(line_user_id);
```

#### groups（グループ）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| line_group_id | text | LINE のグループID（一意） |
| name | text | グループ名（任意） |
| created_by | uuid | 追加したユーザー（FK → users） |
| settings | jsonb | グループ設定 |
| created_at | timestamp | 作成日時 |
| updated_at | timestamp | 更新日時 |

**settings の構造：**
```json
{
  "invite_frequency": "biweekly",
  "default_anonymous": false,
  "min_participants": 3,
  "reminder_enabled": true,
  "vote_deadline_days": 7
}
```

```sql
CREATE TABLE groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  line_group_id text UNIQUE NOT NULL,
  name text,
  created_by uuid REFERENCES users(id),
  settings jsonb DEFAULT '{
    "invite_frequency": "biweekly",
    "default_anonymous": false,
    "min_participants": 3,
    "reminder_enabled": true,
    "vote_deadline_days": 7
  }'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_groups_line_group_id ON groups(line_group_id);
```

#### group_members（グループメンバー）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| group_id | uuid | FK → groups |
| user_id | uuid | FK → users |
| role | text | admin / member |
| joined_at | timestamp | 参加日時 |

```sql
CREATE TABLE group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES groups(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  role text DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  joined_at timestamptz DEFAULT now(),
  UNIQUE(group_id, user_id)
);

CREATE INDEX idx_group_members_group ON group_members(group_id);
CREATE INDEX idx_group_members_user ON group_members(user_id);
```

#### events（確定予定）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| group_id | uuid | FK → groups |
| title | text | 予定タイトル |
| description | text | 詳細（任意） |
| date | date | 予定日 |
| status | text | voting / confirmed / completed / cancelled / pending |
| created_by | uuid | FK → users |
| vote_deadline | timestamp | 投票締切日時 |
| created_at | timestamp | 作成日時 |
| updated_at | timestamp | 更新日時 |

```sql
CREATE TABLE events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES groups(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  date date,
  status text DEFAULT 'voting' CHECK (status IN ('voting', 'confirmed', 'completed', 'cancelled', 'pending')),
  created_by uuid REFERENCES users(id),
  vote_deadline timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_events_group ON events(group_id);
CREATE INDEX idx_events_status ON events(status);
CREATE INDEX idx_events_date ON events(date);
```

#### votes（日程投票）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| event_id | uuid | FK → events |
| user_id | uuid | FK → users |
| date | date | 投票対象の日付 |
| response | text | ok / maybe / ng |
| created_at | timestamp | 投票日時 |
| updated_at | timestamp | 更新日時 |

```sql
CREATE TABLE votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  date date NOT NULL,
  response text NOT NULL CHECK (response IN ('ok', 'maybe', 'ng')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(event_id, user_id, date)
);

CREATE INDEX idx_votes_event ON votes(event_id);
CREATE INDEX idx_votes_user ON votes(user_id);
```

#### wishes（行きたい予定）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| group_id | uuid | FK → groups |
| title | text | 行きたい内容 |
| description | text | 詳細（任意） |
| created_by | uuid | FK → users |
| is_anonymous | boolean | 匿名投稿か |
| status | text | open / voting / converted / archived |
| converted_to | uuid | FK → events（予定に変換された場合） |
| created_at | timestamp | 作成日時 |

```sql
CREATE TABLE wishes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES groups(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  created_by uuid REFERENCES users(id),
  is_anonymous boolean DEFAULT false,
  status text DEFAULT 'open' CHECK (status IN ('open', 'voting', 'converted', 'archived')),
  converted_to uuid REFERENCES events(id),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_wishes_group ON wishes(group_id);
CREATE INDEX idx_wishes_status ON wishes(status);
```

#### interests（興味表明）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| wish_id | uuid | FK → wishes |
| user_id | uuid | FK → users |
| created_at | timestamp | 表明日時 |

```sql
CREATE TABLE interests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wish_id uuid REFERENCES wishes(id) ON DELETE CASCADE,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(wish_id, user_id)
);

CREATE INDEX idx_interests_wish ON interests(wish_id);
```

#### reminders（リマインダー）

| カラム | 型 | 説明 |
|--------|-----|------|
| id | uuid | PK |
| group_id | uuid | FK → groups |
| event_id | uuid | FK → events（任意） |
| type | text | invite / vote_reminder / week_before / day_before / day_of |
| scheduled_at | timestamp | 予定送信日時 |
| sent_at | timestamp | 実際の送信日時（null = 未送信） |
| created_at | timestamp | 作成日時 |

```sql
CREATE TABLE reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid REFERENCES groups(id) ON DELETE CASCADE,
  event_id uuid REFERENCES events(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('invite', 'vote_reminder', 'week_before', 'day_before', 'day_of')),
  scheduled_at timestamptz NOT NULL,
  sent_at timestamptz,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_reminders_scheduled ON reminders(scheduled_at) WHERE sent_at IS NULL;
CREATE INDEX idx_reminders_group ON reminders(group_id);
```

---

## 🌐 API 設計

### LINE Webhook

```
POST /api/webhook
```

**受け取るイベント：**

| イベント | 処理 |
|---------|------|
| follow | ユーザー登録 |
| unfollow | （何もしない） |
| join | グループ登録、メンバー追加 |
| leave | グループ削除 |
| memberJoined | メンバー追加 |
| memberLeft | メンバー削除 |
| message | テキスト処理（将来用） |
| postback | ボタン押下処理 |

### LIFF 用 API

#### グループ

| Method | Endpoint | 説明 |
|--------|----------|------|
| GET | /api/groups | 参加グループ一覧 |
| GET | /api/groups/[id] | グループ詳細 |
| PATCH | /api/groups/[id]/settings | 設定更新 |

#### 予定（Events）

| Method | Endpoint | 説明 |
|--------|----------|------|
| GET | /api/groups/[id]/events | 予定一覧 |
| POST | /api/groups/[id]/events | 予定作成 |
| GET | /api/events/[id] | 予定詳細 |
| PATCH | /api/events/[id] | 予定更新 |
| DELETE | /api/events/[id] | 予定削除 |
| POST | /api/events/[id]/confirm | 予定確定 |

#### 投票（Votes）

| Method | Endpoint | 説明 |
|--------|----------|------|
| GET | /api/events/[id]/votes | 投票状況 |
| POST | /api/events/[id]/votes | 投票送信 |
| PUT | /api/events/[id]/votes | 投票更新 |

#### 行きたい（Wishes）

| Method | Endpoint | 説明 |
|--------|----------|------|
| GET | /api/groups/[id]/wishes | 行きたい一覧 |
| POST | /api/groups/[id]/wishes | 行きたい追加 |
| DELETE | /api/wishes/[id] | 行きたい削除 |
| POST | /api/wishes/[id]/interest | 興味追加 |
| DELETE | /api/wishes/[id]/interest | 興味取消 |
| POST | /api/wishes/[id]/convert | 予定に変換 |

---

## 📱 画面設計

### 画面一覧

| 画面 | パス | 説明 |
|------|------|------|
| ホーム | /liff | 直近の予定、通知 |
| カレンダー | /liff/calendar | 月表示で予定確認 |
| 予定詳細 | /liff/events/[id] | 予定の詳細、投票状況 |
| 日程投票 | /liff/events/[id]/vote | ○△✕入力 |
| 行きたいリスト | /liff/wishes | 日付なし予定一覧 |
| 行きたい追加 | /liff/wishes/new | 新規追加フォーム |
| 設定 | /liff/settings | グループ設定 |

### ワイヤーフレーム

#### ホーム画面

```
┌─────────────────────────────┐
│ 🏠 NextHang                 │
├─────────────────────────────┤
│                             │
│  📅 直近の予定              │
│  ┌───────────────────────┐  │
│  │ 1/15(水) 🍖 焼肉       │  │
│  │ 投票中 → あと3日       │  │
│  └───────────────────────┘  │
│  ┌───────────────────────┐  │
│  │ 1/28(火) 🎤 カラオケ   │  │
│  │ 確定 → 5人参加        │  │
│  └───────────────────────┘  │
│                             │
│  ⭐ 行きたい (3件)          │
│  ┌───────────────────────┐  │
│  │ ユニバ 👀 4人興味あり  │  │
│  └───────────────────────┘  │
│                             │
├─────────────────────────────┤
│ [🏠] [📅] [⭐] [⚙️]        │
└─────────────────────────────┘
```

#### 日程投票画面

```
┌─────────────────────────────┐
│ ← 🍖 焼肉の日程              │
├─────────────────────────────┤
│                             │
│       ◀ 2025年1月 ▶        │
│  日 月 火 水 木 金 土       │
│        1  2  3  4          │
│  5  6  7  8  9 10 11       │
│ 12 13 14 ⭕ 16 17 18       │
│ 19 20 21 22 23 24 25       │
│ 26 27 △ 29 30 31          │
│                             │
│  ─────────────────────────  │
│  選択中：                   │
│  ⭕ 15(水) 行ける           │
│  △ 28(火) 微妙             │
│                             │
│  [送信する]                 │
│                             │
├─────────────────────────────┤
│ [🏠] [📅] [⭐] [⚙️]        │
└─────────────────────────────┘
```

#### まとめ投票画面

```
┌─────────────────────────────┐
│ ← 2月中旬の予定             │
├─────────────────────────────┤
│                             │
│  3件の予定があります        │
│  まとめて回答してね         │
│                             │
│  ┌───────────────────────┐  │
│  │ 2/14(金) 🍖 焼肉       │  │
│  │ ○ 行ける              │  │
│  │ △ 微妙   ← 選択中     │  │
│  │ ✕ 無理               │  │
│  └───────────────────────┘  │
│                             │
│  ┌───────────────────────┐  │
│  │ 2/16(日) 🎤 カラオケ   │  │
│  │ ○ 行ける  ← 選択中    │  │
│  │ △ 微妙               │  │
│  │ ✕ 無理               │  │
│  └───────────────────────┘  │
│                             │
│  [まとめて送信]             │
│                             │
└─────────────────────────────┘
```

#### 設定画面

```
┌─────────────────────────────┐
│ ← 設定                      │
├─────────────────────────────┤
│                             │
│  📢 お誘い頻度              │
│  ┌───────────────────────┐  │
│  │ ○ 毎週                │  │
│  │ ● 2週間ごと ← 選択中  │  │
│  │ ○ 月1回               │  │
│  │ ○ オフ                │  │
│  └───────────────────────┘  │
│                             │
│  🙈 投稿のデフォルト        │
│  ┌───────────────────────┐  │
│  │ 匿名      [OFF]       │  │
│  └───────────────────────┘  │
│                             │
│  👥 最低参加人数            │
│  ┌───────────────────────┐  │
│  │ [  3  ] 人            │  │
│  └───────────────────────┘  │
│                             │
│  🔔 リマインド              │
│  ┌───────────────────────┐  │
│  │ 1週間前    [ON]       │  │
│  │ 前日       [ON]       │  │
│  │ 当日       [OFF]      │  │
│  └───────────────────────┘  │
│                             │
│  [保存]                     │
│                             │
└─────────────────────────────┘
```

---

## 🔔 通知設計

### Bot が送る通知

| 種類 | タイミング | 文面例 |
|------|-----------|--------|
| 定期お誘い | 設定に応じて | 「🤖 そろそろ遊びませんか？\n最近の行きたいリストはこちら→」 |
| 投票開始 | 予定作成時 | 「🗳 新しい予定の投票が始まりました！\n🍖 焼肉\n[投票する]」 |
| 投票リマインド | 締切2日前 | 「⏰ 投票締切まであと2日！\nまだの人は投票してね」 |
| 予定確定 | 確定時 | 「🎉 予定が決まりました！\n1/15(水) 焼肉\n参加者: 5人」 |
| 1週間前 | 7日前 | 「📅 来週の予定\n1/15(水) 焼肉」 |
| 前日 | 1日前 | 「📅 明日の予定\n焼肉 🍖\nお忘れなく！」 |
| 当日 | 当日朝 | 「🎊 今日は焼肉の日！\n楽しんできてね」 |
| 保留 | 人数不足時 | 「😢 今回は人数が集まりませんでした\nまたタイミング見て聞きますね」 |
| 興味閾値超え | 閾値到達時 | 「⭐ ユニバに4人興味あり！\n日程決めませんか？\n[日程を決める]」 |

---

## 📁 ディレクトリ構成

```
nexthang/
├── public/
│   └── sw.js
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── webhook/
│   │   │   │   └── route.ts        # LINE Webhook
│   │   │   ├── groups/
│   │   │   │   ├── route.ts
│   │   │   │   └── [id]/
│   │   │   │       ├── route.ts
│   │   │   │       ├── events/
│   │   │   │       │   └── route.ts
│   │   │   │       ├── wishes/
│   │   │   │       │   └── route.ts
│   │   │   │       └── settings/
│   │   │   │           └── route.ts
│   │   │   ├── events/
│   │   │   │   └── [id]/
│   │   │   │       ├── route.ts
│   │   │   │       ├── votes/
│   │   │   │       │   └── route.ts
│   │   │   │       └── confirm/
│   │   │   │           └── route.ts
│   │   │   └── wishes/
│   │   │       └── [id]/
│   │   │           ├── route.ts
│   │   │           ├── interest/
│   │   │           │   └── route.ts
│   │   │           └── convert/
│   │   │               └── route.ts
│   │   ├── liff/
│   │   │   ├── layout.tsx          # LIFF共通レイアウト
│   │   │   ├── page.tsx            # ホーム
│   │   │   ├── calendar/
│   │   │   │   └── page.tsx
│   │   │   ├── events/
│   │   │   │   └── [id]/
│   │   │   │       ├── page.tsx    # 予定詳細
│   │   │   │       └── vote/
│   │   │   │           └── page.tsx
│   │   │   ├── wishes/
│   │   │   │   ├── page.tsx        # 行きたいリスト
│   │   │   │   └── new/
│   │   │   │       └── page.tsx
│   │   │   └── settings/
│   │   │       └── page.tsx
│   │   ├── layout.tsx
│   │   └── page.tsx                # ランディング（任意）
│   ├── components/
│   │   ├── ui/                     # 汎用UI
│   │   ├── calendar/               # カレンダー関連
│   │   ├── vote/                   # 投票関連
│   │   └── liff/                   # LIFF関連
│   ├── hooks/
│   │   ├── use-liff.ts
│   │   ├── use-groups.ts
│   │   ├── use-events.ts
│   │   └── use-wishes.ts
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts
│   │   │   └── server.ts
│   │   ├── line/
│   │   │   ├── client.ts           # LINE API クライアント
│   │   │   ├── webhook.ts          # Webhook ハンドラ
│   │   │   └── messages.ts         # メッセージテンプレート
│   │   └── utils/
│   │       └── date.ts
│   └── types/
│       ├── database.ts             # Supabase型
│       └── line.ts                 # LINE型
├── supabase/
│   ├── migrations/                 # マイグレーション
│   └── functions/                  # Edge Functions
│       ├── send-reminders/
│       │   └── index.ts
│       └── send-invites/
│           └── index.ts
├── .env.local
├── next.config.js
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

---

## 🔐 環境変数

```env
# LINE
LINE_CHANNEL_ID=
LINE_CHANNEL_SECRET=
LINE_CHANNEL_ACCESS_TOKEN=
LIFF_ID=

# Supabase
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

# App
NEXT_PUBLIC_APP_URL=https://nexthang.vercel.app
```

---

## 🔒 セキュリティ設計

### 認証フロー

```
LIFF 経由のアクセス
    ↓
liff.getProfile() で LINE ユーザーID取得
    ↓
API リクエストに LINE ユーザーID を含める
    ↓
サーバー側で LIFF トークン検証
    ↓
ユーザーID と グループID の紐付け確認
    ↓
データアクセス許可
```

### RLS（Row Level Security）

```sql
-- 例：votes テーブル
ALTER TABLE votes ENABLE ROW LEVEL SECURITY;

-- グループメンバーなら全員の投票を見れる
CREATE POLICY "Group members can view votes"
  ON votes FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM events e
      JOIN group_members gm ON e.group_id = gm.group_id
      WHERE e.id = votes.event_id
      AND gm.user_id = current_user_id()
    )
  );
```

---

## 📅 開発スケジュール

### Phase 1（2-3週間）

- [ ] プロジェクト初期化
- [ ] LINE 公式アカウント作成
- [ ] DB セットアップ（テーブル作成）
- [ ] Webhook 実装（follow, join, leave）
- [ ] LIFF 基本画面（ホーム）
- [ ] 日程投票機能

### Phase 2（2週間）

- [ ] リマインド機能
- [ ] 行きたいリスト
- [ ] 興味投票
- [ ] まとめ投票
- [ ] 設定画面

### Phase 3（2週間）

- [ ] リッチメニュー
- [ ] Flex Message 整備
- [ ] 定期お誘い（Cron）
- [ ] 保留→復活機能
- [ ] テスト・バグ修正

### Phase 4（将来）

- [ ] おすすめ提案
- [ ] Google Calendar 連携
- [ ] 年間レポート

---

## 📚 参考リンク

- [LINE Messaging API ドキュメント](https://developers.line.biz/ja/docs/messaging-api/)
- [LIFF ドキュメント](https://developers.line.biz/ja/docs/liff/)
- [Supabase ドキュメント](https://supabase.com/docs)
- [Next.js ドキュメント](https://nextjs.org/docs)
- [Vercel ドキュメント](https://vercel.com/docs)

---

## 変更履歴

| 日付 | バージョン | 内容 |
|------|-----------|------|
| 2026/01/31 | v1.0 | 初版作成 |
